object_metadata = {
    "typeVersion": 1, 
    "startAt": "2024-04-04", 
    "data": {  
        "smaak": "vies",
        "aantal": 20
    }
}