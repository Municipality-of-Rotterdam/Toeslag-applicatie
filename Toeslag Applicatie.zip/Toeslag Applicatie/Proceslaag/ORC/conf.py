def urls_tokens():
    return {
    'base_url_objects': "http://localhost:8000/api/v2",
    'base_url_object_types': "http://localhost:8001/api/v1",
    'base_url_object_types_internal': "http://host.docker.internal:8001/api/v1",
    'base_url_objects_zorgtoeslag': "http://localhost:8000/api/v1/objects?type=http://host.docker.internal:8001/api/v1/objecttypes/e55e6e35-651f-49c9-a4b3-e0646d6e429b",
    'base_url_objects_kinderbijslag': "http://localhost:8000/api/v1/objects?type=http://host.docker.internal:8001/api/v1/objecttypes/474415d1-f462-468b-aadf-2e4123011598",
    'token_objects': "cd63e158f3aca276ef284e3033d020a22899c728",
    'token_object_types': "7931f4ed20c531b422dc2d9693f1d280e5d12807",
    }

